ID:{{$generos->id_genero}}<br>
Nome:{{$generos->designacao}}<br>
Morada:{{$generos->observacoes}}