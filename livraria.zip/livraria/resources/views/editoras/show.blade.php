ID:{{$editora->id_editor}}<br>
Nome:{{$editora->nome}}<br>
Morada:{{$editora->morada}}